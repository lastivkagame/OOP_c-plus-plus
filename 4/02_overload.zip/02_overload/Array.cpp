#include "Array.h"

void main()
{
	Array arr; // ctor default
	arr.Print();
	cout << "arr[5] = " << arr[5] << endl;
	arr[5] = 100; // []
	arr.Print();
	Array arr2; // default
	arr2.Print();
	arr2 = arr; // =
	Array arr3 = arr2; // ctor copy
	cout << endl;
	arr2.Print();
	cout << "===============\n\n\n";
	cout <<"op ++arr2 : " <<  (++arr2).GetSize() << endl;
	cout <<"op --arr2 : " <<  (--arr2).GetSize() << endl;
	cout <<"op arr2++ : " <<  (arr2++).GetSize() << endl;

}