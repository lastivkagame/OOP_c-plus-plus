﻿#include <iostream>
#include <string>
using namespace std;

template <typename T>
T Max(T x, T y) // узагальнений шаблон
{
	cout << "General template works! T Max(T x, T y) \n";
	return x > y ? x : y;
}
template <> float Max(float x, float y) // спеціалізація шаблону Max для типу float
{
	cout << "Specialization template works!  Max(float x, float y) \n";
	return x > y ? x : y;
}
float Max(float x, float y) // звичайна функція
{
	cout << "Ordinary function works! float Max(float x, float y) \n";
	return x > y ? x : y;
}
char Max(char x, char y)
{
	cout << "Usual function works! char Max(char x, char y) \n";
	return tolower(x) > tolower(y) ? x : y; // tolower - переведи в нижній регістр! (маленька літера)
}
template <typename T>
T Max(const T arr[], int size)
{
	T max = arr[0];
	for (int i = 1; i < size; i++)
		if (arr[i] > max)
			max = arr[i];
	return max;
}
template <typename T1, typename T2>
auto Sum(T1 x, T2 y) // auto - дозволяємо компілятору визначити тип самостійно
{
	cout << "General template works! T Sum(T x, T y) \n";
	return x + y;
}
// пріоритет виклику: 
// 1) звичайна функція
//2) спеціалізація 
// 3) шаблонна функція
void main()
{
	cout << "Max(100,200) = " << Max(100,200) << endl;
	cout << "Max(-10.5,20.56) = " << Max(-10.5, 20.56) << endl; // T = double
	cout << "Max(-10.5f,20.56f) = " << Max(-10.5f, 20.56f) << endl; // ordinary
	cout << "Max<float>(-10.5,20.56) = " << Max<float>(-10.5, 20.56) << endl; // spec

	cout << "Max('a', 'Z') = " << Max<char>('a', 'Z') << endl;
	char * arr = new char[5] { 68,78,97,65,20 };
	cout << "Max array: " << Max(arr, 5) << endl; // general
	cout << "Sum " << Sum(10, 12.5) << endl;

	string str = "Hello world!";
	for (auto el : str) // char el // compile define el as char
	{
		cout << el << ' ';
	}
	cout << endl;


	system("pause");
}