#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Person {
protected:
	string name;
	int age;
public:
	Person(string name, int age): name(name), age(age){
		cout << "Person(string name, int age)\n";
	}
	void show() const
	{
		cout << "Person: " << name << "\t " << age << "y.o.\n";
	}
	string getName() const {
		return name;
	}
};

class Programmer:public virtual Person
{
private:
	vector<string> skills;
public:
	Programmer(string name, int age) : Person(name, age) 
	{
		skills.push_back("C++");
		cout << "	Programmer(string name, int age) \n";
	}
	void addSkill(string skill)
	{
		skills.push_back(skill);
	}
	void showSkills() const
	{
		cout << name << "'s skills: ";
		for (int i = 0; i < skills.size(); i++)
		{
			cout << skills[i] << "\t";
		}
		cout << endl;
	}
};
class Singer : public virtual Person
{
	string voice;
public:
	Singer(string name = "noname", int age = 18, string voice = "bass") : Person(name, age) {
		this->voice = voice;
		cout << "Singer(string name = \"noname\", int age = 18, string voice = \"bass\")\n";
	}
	Singer(Person &p, string voice) : Person(p), voice(voice) {
		cout << "Singer(Person &p, string voice)\n";
	}

	void show() const {
		Person::show();
		cout << "voice: " << voice << endl;
	}
};

class SigningProgrammer : public Programmer, public Singer
{
public:
	SigningProgrammer(string name, int age, string voice) : Programmer(name, age),
		Singer(name, age, voice), Person(name, age) {
		cout << "SigningProgrammer(string name, int age, string voice)\n";
	}
};
