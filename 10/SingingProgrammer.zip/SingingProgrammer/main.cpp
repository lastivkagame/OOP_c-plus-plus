#include "Person.h"

void main()
{
	Person max("Max", 16), andrew("Andrew", 17);
	max.show();
	andrew.show();

	Programmer andrew2("Andrew", 18);
	andrew2.show(); // person
	andrew2.addSkill("C#");
	andrew2.addSkill("Python");
	andrew2.showSkills();

	system("pause");
	Singer kolia("Kolia", 20);
	kolia.show();
	system("pause");

	SigningProgrammer sasha("sasha", 25, "soprano");
	cout << "Singing programmer name = " << sasha.getName() << endl;
	sasha.show();
	sasha.showSkills();
	system("pause");
}