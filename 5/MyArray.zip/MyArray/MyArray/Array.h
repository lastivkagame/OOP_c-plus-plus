#pragma once
#include <iostream>
#include <ctime>
using namespace std;
class Array
{
	int size;
	int* arr;
	bool validateIndex(int index);
public:
	Array();
	Array(int size);
	Array(const Array& obj);
	~Array();

	int getSize() const;
	int* getArr() const;

	void setSize(int size);
	void setArr(int size, const int* arr);

	void fill();
	void print() const;
	void Add(int el);
	void Remove(int index);
	Array& operator = (const Array& obj);
	Array& operator+(const Array& right);
	friend Array operator+(int el, const Array& left);
	friend ostream& operator << (ostream& os,  const Array& right);
	friend istream& operator >> (istream& is, Array& right);
	Array operator++(int);
	int& operator[] (int index);
};

