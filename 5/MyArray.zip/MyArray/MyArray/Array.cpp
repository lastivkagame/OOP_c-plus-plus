#include "Array.h"


bool Array::validateIndex(int index)
{
	if (index >= 0 && index < size)
		return true;
	return false;
}

Array::Array()
{
	setSize(10);
}

Array::Array(int size)
{
	setSize(size);
}

Array::Array(const Array& obj)
{
	setArr(obj.getSize(), obj.getArr());
}

Array::~Array()
{
	if (arr != nullptr)
	{
		delete[] arr;
		arr = nullptr;
	}
}

int Array::getSize() const
{
	return size;
}

int* Array::getArr() const
{
	return arr;
}

void Array::setSize(int size)
{
	this->size = size;
	this->arr = new int[size];

}

void Array::setArr(int size, const int* arr)
{
	setSize(size);
	for (int i = 0; i < size; i++)
	{
		this->arr[i] = arr[i];
	}
}

void Array::fill()
{
	for (int i = 0; i < size; i++)
	{
		arr[i] = rand() % 20;
	}
}

void Array::print() const
{
	for (int i = 0; i < size; i++)
	{
		cout << arr[i] << "\t";
	}
	cout << endl;
}

void Array::Add(int el)
{
	Array temp(size + 1);
	for (int i = 0; i < size; i++)
	{
		temp.getArr()[i] = this->arr[i];
	}
	temp.getArr()[size] = el;
	setArr(temp.getSize(), temp.getArr());
}

void Array::Remove(int index)
{
	if (!validateIndex(index)) // if(validateIndex(index) == false)
		return; // ������ ������ ������
	Array temp(size - 1);
	for (int i = 0; i < temp.getSize(); i++)
	{
		if (i < index)
		{
			temp.getArr()[i] = this->arr[i];
		}
		else
			temp.getArr()[i] = this->arr[i + 1];
	}
//	delete[] arr;
	*this = temp; // operator =
}

Array& Array::operator=(const Array& obj)
{
	if (this == &obj) // �������� �� �������������
		return *this;
	setArr(obj.getSize(), obj.getArr());
	return *this;
}

Array& Array::operator+(const Array& right)
{
	Array temp(this->size + right.getSize());
	for (int i = 0; i < this->size; i++)
		temp.getArr()[i] = this->arr[i];
	for (int i = size; i < temp.getSize(); i++)
	{
		temp.getArr()[i] = right.getArr()[i - size];
	}
	*this = temp;
	return *this;
}

Array Array::operator++(int)
{
	Array temp = *this; // ctor copy
	for (int i = 0; i < size; i++)
	{
		arr[i]++;
	}
	return temp;
}

int& Array::operator[](int index)
{
	if (validateIndex(index))
	//if (index >= 0 && index < size)
		return arr[index];
	throw "index error"; // �������� �������!!!
	//cerr << "index error" << endl;
}


Array operator+(int el, const Array& left)
{
	Array temp(left.getSize());
//	temp.setArr(left.getSize(), left.getArr());
	for (int i = 0; i < temp.getSize(); i++)
	{
		temp[i] = left.getArr()[i] + el;
	}
	return temp;
}

 ostream& operator<<(ostream& os, const Array& right)
{
	for (int i = 0; i < right.getSize(); i++)
	{
		os << right.getArr()[i] << "\t";
	}
	os << endl;
	return os;
}

 istream& operator>>(istream& is, Array& right)
 {
	 for (int i = 0; i < right.getSize(); i++)
	 {
		 is >> right[i];
	 }
	 return is;
 }
