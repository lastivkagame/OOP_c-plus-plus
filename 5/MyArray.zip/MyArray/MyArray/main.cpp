#include "Array.h"

void main()
{
	Array arr;
	arr.fill();
	arr.print();
	arr.Add(100);
	arr.print();
	arr.Remove(5);
	arr.print();

	Array arr2(5);
	arr2.fill();
	cout << "Test arr2" << endl;
	arr2.print();
	cout << "_____________op + ______________\n\n";
	Array res = arr + arr2;
	res.print();
	res++;
	cout << "op++(int)" << endl;
	res.print();
	Array temp = 100 + res;
	cout << endl << endl;
	temp.print();

	cout << temp << endl;

	cout << "Input: " << endl;
	cin >> arr2 ;
	cout << arr2 <<endl << arr;
//	cout << arr[-1] << endl;  // error!! invalid index
}